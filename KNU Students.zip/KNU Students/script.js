// Dummy data for notifications with categories, date, and time
let notifications = [
    { title: "Midterm Exams", message: "Midterm exams will be held from 1st September.", category: "academic", dateTime: new Date('2024-08-17T10:30:00'), reactions: { thumbsUp: 10, questionMark: 2 } },
    { title: "Cultural Fest", message: "Join us for the annual cultural fest on 20th August.", category: "cultural", dateTime: new Date('2024-08-18T09:00:00'), reactions: { thumbsUp: 25, questionMark: 5 } },
];

// To store which notifications the user has reacted to
let userReactions = {};

function displayNotifications(filter = "all") {
    const feed = document.querySelector('.notification-feed');
    feed.innerHTML = '<h2>Notifications</h2>'; // Reset feed

    // Sort notifications by date (newest first)
    const sortedNotifications = notifications.sort((a, b) => b.dateTime - a.dateTime);

    sortedNotifications.forEach((notif, index) => {
        if (filter === "all" || notif.category === filter) {
            const isNew = index === 0 ? 'new' : ''; // Mark the most recent notification as new
            const formattedDate = notif.dateTime.toLocaleString('en-US', {
                year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'
            });

            const notificationHTML = `
                <div class="notification ${isNew}" data-category="${notif.category}">
                    <h3>${notif.title}</h3>
                    <span class="date-time">${formattedDate}</span>
                    <p>${notif.message}</p>
                    <div class="reactions">
                        <span class="reaction" data-index="${index}" data-type="thumbsUp" data-reacted="${userReactions[index]?.thumbsUp || false}">👍 ${notif.reactions.thumbsUp}</span>
                        <span class="reaction" data-index="${index}" data-type="questionMark" data-reacted="${userReactions[index]?.questionMark || false}">❤️ ${notif.reactions.questionMark}</span>
                    </div>
                </div>
            `;
            feed.innerHTML += notificationHTML;
        }
    });

    // Add event listeners for reactions
    document.querySelectorAll('.reaction').forEach(element => {
        element.addEventListener('click', handleReaction);
    });
}

// Handle category filtering
document.querySelectorAll('nav ul li a').forEach(link => {
    link.addEventListener('click', function(e) {
        e.preventDefault();
        const filter = this.getAttribute('data-filter');
        displayNotifications(filter);
    });
});

function handleReaction(event) {
    const reactionElement = event.target;
    const index = reactionElement.getAttribute('data-index');
    const type = reactionElement.getAttribute('data-type');

    // Ensure the student can only react once
    if (!userReactions[index]) {
        userReactions[index] = { thumbsUp: false, questionMark: false };
    }
    if (!userReactions[index][type]) {
        userReactions[index][type] = true;
        notifications[index].reactions[type]++;
        displayNotifications();
    }
}

// Admin password protection
document.getElementById('adminLink').addEventListener('click', function(e) {
    e.preventDefault();
    const password = prompt("Enter Admin Password:");
    if (password === "Allahisgreat@786") {
        document.getElementById('title').disabled = false;
        document.getElementById('message').disabled = false;
        document.getElementById('category').disabled = false;
        document.querySelector('.admin-panel button').disabled = false;
    } else {
        alert("Incorrect password!");
    }
});

// Admin posts a new notification
document.getElementById('postNotification').addEventListener('submit', function(e) {
    e.preventDefault();

    const title = document.getElementById('title').value;
    const message = document.getElementById('message').value;
    const category = document.getElementById('category').value;
    const dateTime = new Date(); // Current date and time

    notifications.push({ title, message, category, dateTime, reactions: { thumbsUp: 0, questionMark: 0 } });
    displayNotifications();

    // Clear the form
    document.getElementById('title').value = '';
    document.getElementById('message').value = '';
    document.getElementById('category').value = '';
});

// Initial display of notifications
displayNotifications();
